// Toggle Sidebar
function toggleSidebar() {
    let sidebar = document.getElementById("sidebar");
    let content = document.getElementById("mainContent");

    if (sidebar.classList.contains("open")) {
        sidebar.classList.remove("open");
        sidebar.style.left = "-250px"; 
        content.style.marginLeft = "0"; 
    } else {
        sidebar.classList.add("open");
        sidebar.style.left = "0"; 
        content.style.marginLeft = "250px"; 
    }
}

// Toggle Profile Dropdown
function toggleDropdown() {
    let dropdown = document.getElementById("profileDropdown");
    dropdown.classList.toggle("show");
}

// Close dropdown if clicking outside
window.onclick = function(event) {
    if (!event.target.matches('.profile-pic') && !event.target.matches('.profile-button span')) {
        let dropdowns = document.getElementsByClassName("dropdown-content");
        for (let i = 0; i < dropdowns.length; i++) {
            let openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
};

// Search Events
function searchEvents() {
    let input = document.getElementById("searchInput").value.toLowerCase();
    let events = document.querySelectorAll(".event-box");

    events.forEach(event => {
        let eventName = event.getAttribute("data-name").toLowerCase();
        if (eventName.includes(input)) {
            event.style.display = "block";
        } else {
            event.style.display = "none";
        }
    });
}

function toggleDropdown2() {
    document.getElementById("languageDropdown").classList.toggle("show");
}

function selectLanguage(language) {
    alert("You selected: " + language);
    document.getElementById("languageDropdown").classList.remove("show");
}

// Close dropdown if clicked outside
document.addEventListener("click", function(event) {
    if (!event.target.closest(".header-right")) {
        document.getElementById("languageDropdown").classList.remove("show");
    }
});

// Load Events from localStorage
document.addEventListener("DOMContentLoaded", function () {
    loadEvents();
});

function loadEvents() {
    const eventContainer = document.getElementById("eventContainer");
    eventContainer.innerHTML = ""; // Clear previous events

    let events = JSON.parse(localStorage.getItem("events")) || [];

    events.forEach(event => {
        const eventBox = document.createElement("div");
        eventBox.classList.add("event-box");
        eventBox.setAttribute("data-name", event.name);
        eventBox.onclick = function () {
            openEventPage(event.image, event.name, event.description);
        };

        const img = document.createElement("img");
        img.src = event.image || "../src/default.jpg"; // Use a default image if none is uploaded
        img.alt = event.name;

        const overlay = document.createElement("div");
        overlay.classList.add("overlay");
        overlay.textContent = event.name;

        eventBox.appendChild(img);
        eventBox.appendChild(overlay);
        eventContainer.appendChild(eventBox);
    });
}

function openEventPage(image, name, description) {
    localStorage.setItem("eventImage", image);
    localStorage.setItem("eventName", name);
    localStorage.setItem("eventDescription", description);
    window.location.href = "event_details.html";
}

// Logout Function
function logout() {
    localStorage.removeItem("authToken"); // Remove authentication token
    window.location.href = "/mstp/auth.html"; // Redirect to login page
}
