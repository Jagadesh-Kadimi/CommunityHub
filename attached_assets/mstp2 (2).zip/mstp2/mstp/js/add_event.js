document.getElementById("eventForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form from submitting normally

    let eventName = document.getElementById("eventName").value.trim();
    let eventDate = document.getElementById("eventDate").value;
    let eventTime = document.getElementById("eventTime").value;
    let eventLocation = document.getElementById("eventLocation").value.trim();
    let eventDescription = document.getElementById("eventDescription").value.trim();
    let eventImage = document.getElementById("eventImage").files[0];

    if (!eventName || !eventDate || !eventTime || !eventLocation || !eventDescription) {
        alert("Please fill in all fields.");
        return;
    }

    if (!eventImage) {
        alert("Please upload an event image.");
        return;
    }

    // Resize image before storing
    resizeImage(eventImage, 500, 500, function(compressedImage) {
        let newEvent = {
            name: eventName,
            date: eventDate,
            time: eventTime,
            location: eventLocation,
            description: eventDescription,
            image: compressedImage  // Use compressed image
        };

        // Retrieve existing events from localStorage
        let events = JSON.parse(localStorage.getItem("events")) || [];
        events.push(newEvent);

        try {
            localStorage.setItem("events", JSON.stringify(events));
            alert("Event added successfully!");
            window.location.href = "/mstp/mainpage.html"; // Redirect after adding event
        } catch (e) {
            alert("Storage limit exceeded! Consider clearing localStorage or using a database.");
        }
    });
});

// Function to resize and compress image before storing
function resizeImage(file, maxWidth, maxHeight, callback) {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = function(event) {
        let img = new Image();
        img.src = event.target.result;
        img.onload = function() {
            let canvas = document.createElement("canvas");
            let ctx = canvas.getContext("2d");

            let width = img.width;
            let height = img.height;

            // Resize if needed
            if (width > maxWidth) {
                height *= maxWidth / width;
                width = maxWidth;
            }
            if (height > maxHeight) {
                width *= maxHeight / height;
                height = maxHeight;
            }

            canvas.width = width;
            canvas.height = height;
            ctx.drawImage(img, 0, 0, width, height);

            // Convert to Base64 with compression (JPEG format, 70% quality)
            let compressedData = canvas.toDataURL("image/jpeg", 0.7);
            callback(compressedData);
        };
    };
}

// Show image preview before submission
document.getElementById("eventImage").addEventListener("change", function(event) {
    let file = event.target.files[0];
    if (file) {
        let reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById("imagePreview").innerHTML = `<img src="${e.target.result}" alt="Event Image">`;
        };
        reader.readAsDataURL(file);
    }
});

// Back Button Function
function goBack() {
    window.location.href = "/mstp/mainpage.html";
}
