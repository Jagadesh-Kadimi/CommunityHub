document.addEventListener("DOMContentLoaded", function () {
    // Load saved data from localStorage
    if (localStorage.getItem("profileName")) {
        document.getElementById("profileName").innerText = localStorage.getItem("profileName");
        document.getElementById("sidebarName").innerText = localStorage.getItem("profileName");
        document.getElementById("nameText").innerText = localStorage.getItem("profileName");
    }
    if (localStorage.getItem("aboutText")) {
        document.getElementById("aboutText").innerText = localStorage.getItem("aboutText");
    }
    if (localStorage.getItem("emailText")) {
        document.getElementById("emailText").innerText = localStorage.getItem("emailText");
    }
    if (localStorage.getItem("memberSinceText")) {
        document.getElementById("memberSinceText").innerText = localStorage.getItem("memberSinceText");
    }
    if (localStorage.getItem("locationText")) {
        document.getElementById("locationText").innerText = localStorage.getItem("locationText");
    }

    // About me edit functionality
    document.getElementById("editAbout").addEventListener("click", function () {
        document.getElementById("aboutInput").classList.remove("hidden");
        document.getElementById("aboutInput").value = document.getElementById("aboutText").innerText;
        document.getElementById("aboutText").classList.add("hidden");
        document.getElementById("saveAbout").classList.remove("hidden");
        document.getElementById("editAbout").classList.add("hidden");
    });

    document.getElementById("saveAbout").addEventListener("click", function () {
        let updatedAbout = document.getElementById("aboutInput").value.trim();
        if (updatedAbout) {
            document.getElementById("aboutText").innerText = updatedAbout;
            localStorage.setItem("aboutText", updatedAbout);
        }
        document.getElementById("aboutInput").classList.add("hidden");
        document.getElementById("aboutText").classList.remove("hidden");
        document.getElementById("saveAbout").classList.add("hidden");
        document.getElementById("editAbout").classList.remove("hidden");
    });

    // Details edit functionality
    document.getElementById("editDetails").addEventListener("click", function () {
        document.getElementById("detailsForm").classList.remove("hidden");
        document.getElementById("nameInput").value = document.getElementById("nameText").innerText;
        document.getElementById("emailInput").value = document.getElementById("emailText").innerText;
        document.getElementById("memberSinceInput").value = document.getElementById("memberSinceText").innerText;
        document.getElementById("locationInput").value = document.getElementById("locationText").innerText;
    });

    document.getElementById("saveDetails").addEventListener("click", function () {
        let updatedName = document.getElementById("nameInput").value.trim();
        let updatedEmail = document.getElementById("emailInput").value.trim();
        let updatedMemberSince = document.getElementById("memberSinceInput").value.trim();
        let updatedLocation = document.getElementById("locationInput").value.trim();

        if (updatedName) {
            document.getElementById("nameText").innerText = updatedName;
            document.getElementById("profileName").innerText = updatedName;
            document.getElementById("sidebarName").innerText = updatedName;
            localStorage.setItem("profileName", updatedName);
        }
        if (updatedEmail) {
            document.getElementById("emailText").innerText = updatedEmail;
            localStorage.setItem("emailText", updatedEmail);
        }
        if (updatedMemberSince) {
            document.getElementById("memberSinceText").innerText = updatedMemberSince;
            localStorage.setItem("memberSinceText", updatedMemberSince);
        }
        if (updatedLocation) {
            document.getElementById("locationText").innerText = updatedLocation;
            localStorage.setItem("locationText", updatedLocation);
        }

        document.getElementById("detailsForm").classList.add("hidden");
    });
});
