import { initializeApp } from "https://www.gstatic.com/firebasejs/11.2.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.2.0/firebase-auth.js";

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyCoD9la16WRsZkAM47k1FBrzmZx9o1ErCs",
  authDomain: "mstlab.firebaseapp.com",
  projectId: "mstlab",
  storageBucket: "mstlab.firebasestorage.app",
  messagingSenderId: "2545232988",
  appId: "1:2545232988:web:398baf99bdcaec933f0a99",
  measurementId: "G-G5HNMZNBZP"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Register User
const registerButton = document.getElementById('submit');
registerButton.addEventListener('click', function(event) {
  event.preventDefault(); // Prevent form submission
  
  // Get email and password values after the button click
  const Email = document.getElementById('register-email').value;
  const password = document.getElementById('register-password').value;

  // Validate email and password fields
  if (!Email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  // Call Firebase function to create user with email and password
  createUserWithEmailAndPassword(auth, Email, password)
    .then((userCredential) => {
      // Signed up successfully
      const user = userCredential.user;
      alert("Registration Successful! Welcome, " + user.email);
      console.log("User Info:", user);
      window.location.replace('auth.html')
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      // Handle errors
      alert(`Error ${errorCode}: ${errorMessage}`);
      console.error("Error during registration:", errorCode, errorMessage);
    });
});

// Login User
const loginButton = document.getElementById('login-submit');
loginButton.addEventListener('click', function(event) {
  event.preventDefault(); // Prevent default form submission
  
  // Get email and password values from the login form
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  // Validate email and password fields
  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  // Call Firebase function to login with email and password
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // Login successful
      const user = userCredential.user;
      alert("Login Successful! Welcome, " + user.email);
      console.log("Logged in User Info:", user);
      window.location.replace("mainpage.html");
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      // Handle errors
      alert(`Error ${errorCode}: ${errorMessage}`);
      console.error("Error during login:", errorCode, errorMessage);
    });
});
